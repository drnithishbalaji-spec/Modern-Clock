# Browser testing

The updated package passed the Chromium regression suite with no JavaScript runtime errors or outbound application requests observed.

## Re-run

Start the preview in one terminal:

```sh
./start-local-preview.sh
```

In another terminal, install the optional development dependency and browser, then test:

```sh
python3 -m pip install -r requirements-dev.txt
python3 -m playwright install chromium
python3 tests/test_preview.py --base-url http://127.0.0.1:8765/ --artifacts .test-artifacts
```

The suite uses a system Chromium installation when available; otherwise it uses Playwright's installed Chromium. It writes screenshots and `test-results.json` to the artifact directory.

## Covered behaviors

- Local analog/digital clock ticks and the three default world-time zones remain present.
- Search city names or IANA zones, add clocks, prevent duplicates, remove clocks, and retain the selected list after reload.
- Mouse/touch clicks and keyboard tab navigation switch all five panels, including the dedicated World Clock tab.
- Stopwatch elapsed timing, two laps, pause, resume, and reset.
- Countdown editing, input bounds, pause/resume, edited paused-state reset, zero-duration guard, completion, restart, and reset.
- Adjustable focus/break lengths, paused time remaining, focus completion logged once, and both phase transitions.
- Study durations and history persist after reload; confirmed clearing persists too.
- Every panel fits 390px and 320px screens without page-level horizontal overflow.
- Simulated sleeping-device clock jumps catch up and retain the scheduled focus completion timestamp.
- Corrupt saved history is repaired. Blocked storage falls back to a clearly labelled in-memory log.
- No JavaScript runtime errors or external application data requests are observed.

Timers are accelerated with Playwright's clock controls so completion paths are exercised without waiting through a 25-minute focus session. Preview screenshots show genuine states reached through UI interactions in this test, including a completed 1-minute focus session. No test history is embedded in the app's source or shipped as initial local data.

The app was also served under the project subpath `/New-clock-/`; its `./styles.css` and `./app.js` references resolved correctly there. This updated preview remains separate from the live Meridian site. No GitHub publishing or live-site deployment was performed.
